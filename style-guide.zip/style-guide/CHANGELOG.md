2.1.0 / 2013-07-13
==================

 * Add button that selects sample markup to be copied
 * Resolves issue #4 and issue #6 

2.0.2 / 2013-07-09
==================

 * Resolved issue #3 

2.0.1 / 2013-07-09
==================

 * Removed custom scrollbar styles

2.0.0 / 2013-06-18
==================
 
 * Reworked navigation
 * Reworked layout
 * Added hex values to color swatches
 * Added ability to toggle code snippets
 * Switched to placehold.it for images
 * Switched to prettify.js for code highlighting
 * Improved usability across mobile and legacy browsers
 * Normalized time element formatting

1.9.0 / 2013-06-07
==================
 
 * Normalize formatting for all markup snippets
 * Update tabular data example

1.8.1 / 2013-05-29
==================
 
 * Update sources for video and audio elements

1.8.0 / 2013-05-29
==================

 * Reworked Media section
 * Add Audio example
 * Add Video example
 * Reworked preformatted text
 * Reworked tabular data
 * Add table with side headings

1.7.1 / 2013-05-28
==================
  
 * Fix dynamic output value on range slider

1.7.0 / 2013-05-24
==================
  
 * Add datalist fields

1.6.0 / 2013-05-24
==================
 
 * Reworked Form Buttons section
 * Add disabled buttons
 * Add fieldset examples
 * Reworked Form Fields
 * Add speech recognition input
 * Add time input
 * Add disabled fields
 * Add readonly fields

1.5.0 / 2013-05-24
==================
 
 * Add meter element
 * Add progress element
 
1.4.0 / 2013-05-24
==================
 
 * Add details element
 
1.3.0 / 2013-05-24
==================

 * Remove headings in hgroup
 * Add small text and link in heading examples
 * Add address element
 * Add time element
 * Add q element
 * Add international phone input example
 * Add placeholder example
 * Add required field input
 * Add mulitiple select menu
 * Merge HTML5 Form Fields section into Form Fields section

1.2.0 / 2013-04-02
==================

 * Add media query for small viewports

1.1.0 / 2013-03-22
==================

  * Remove dependancy on jQuery
  * Locally host highlight.js files
  * Use placedog.com instead of lorempixel.com

1.0.0 / 2013-03-06
==================

  * Initial commit
